/* ملف الإعدادات - عدّلي هنا فقط (لا تلمسي script.js) */
window.APP_CONFIG = {
  whatsapp: '',        // رقم واتساب كاملاً مع رمز الدولة بدون + مثال: 2499XXXXXXXX
  telegramToken: '',   // توكن البوت من BotFather
  telegramChat: '',    // رقم المحادثة (Chat ID)
  telegramUrl: ''      // اتركيه فارغاً (للطريقة الآمنة فقط)
};
